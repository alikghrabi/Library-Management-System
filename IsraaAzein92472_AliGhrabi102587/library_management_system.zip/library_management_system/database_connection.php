<?php

//database_connection.php

$connect = new PDO("mysql:host=localhost; port=3306; dbname=lms", "root", "");

session_start();

?>